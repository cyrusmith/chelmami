/**
 * 
 * Use this file only for scripts needed in full version.
 * Before moving from embedded JS - make sure it's needed only here.
 */

jQuery(document).ready(function(){
});