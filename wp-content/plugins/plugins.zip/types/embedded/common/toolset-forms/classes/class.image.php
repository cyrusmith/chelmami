<?php
require_once 'class.file.php';

/**
 * Description of class
 *
 * @author Srdjan
 */
class WPToolset_Field_Image extends WPToolset_Field_File
{
    
}